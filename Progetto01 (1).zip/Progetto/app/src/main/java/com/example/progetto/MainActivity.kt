package com.example.progetto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AvventuraSoldato()
        }
    }
}

@Composable
fun AvventuraSoldato() {
    var scena by remember { mutableStateOf(0) }
    var input by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    val testoScena = when (scena) {
        0 -> "Inizi la tua missione. Scegli un'arma:\n1. M4\n2. AK-47\n3. Revolver"
        1 -> "Hai scelto la tua arma. Ora scegli il percorso:\n1. Veloce ma esposto\n2. Lento ma sicuro"
        2 -> "Sei stato colpito in un'imboscata. Fine missione."
        3 -> "Prosegui lentamente e tutto va bene. Vedi un'auto parcheggiata:\n1. Prova a prenderla\n2. Prosegui a piedi"
        4 -> "L'auto è senza carburante. Sei bloccato. Fine missione hai perso."
        5 -> "Prosegui a piedi. Arrivi a un bivio:\n1. Esplora una casa abbandonata\n2. Attraversa un ponte"
        6 -> "Nella casa c'era una trappola. Fine missione."
        7 -> "Attraversi il ponte. Senti rumori nel bosco:\n1. Investigare\n2. Correre al campo"
        8 -> "Sei caduto in un'imboscata. Fine missione."
        9 -> "Corri al campo e arrivi sano e salvo. Missione compiuta!"
        else -> "Scelta non valida. Riprova."
    }

    fun gestisciScelta(scelta: String) {
        scena = when (scena) {
            0 -> if (scelta in listOf("1", "2", "3")) 1 else -1
            1 -> when (scelta) {
                "1" -> 2
                "2" -> 3
                else -> -1
            }
            3 -> when (scelta) {
                "1" -> 4
                "2" -> 5
                else -> -1
            }
            5 -> when (scelta) {
                "1" -> 6
                "2" -> 7
                else -> -1
            }
            7 -> when (scelta) {
                "1" -> 8
                "2" -> 9
                else -> -1
            }
            else -> 0
        }
        input = ""
        focusManager.clearFocus()
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = testoScena)
            Spacer(modifier = Modifier.height(20.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("Inserisci 1, 2 o 3") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = { gestisciScelta(input) }) {
                Text("Invio")
            }
        }
    }
}
